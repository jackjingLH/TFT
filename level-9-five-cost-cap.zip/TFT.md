<!-- tags: 运营九级,五费大成,登顶阵容 -->
<!-- cover: level-9-five-cost-cap__dataTFT (9).png -->
<!-- backup: level-9-five-cost-cap -->

# 薇古丝 95


![alt text](level-9-five-cost-cap__image-27.png)

如果你拿到了像**升级咯！**、**上进心**这类<u>更容易直冲9人口</u>的强化符文，这把就可以认真考虑走这套。

![alt text](level-9-five-cost-cap__image-28.png)

另外一种典型情况，是你前中期已经打出了连胜，同时还拿到了至少两个金钱类强化符文。只要经济足够顺，这套就很容易变成上分答案。

![alt text](level-9-five-cost-cap__image-29.png)
