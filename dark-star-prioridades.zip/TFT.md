<!-- tags: 新手推荐, 纹章, 速8D牌运营 -->
<!-- cover: comp_image.png -->
<!-- backup: dark-star-prioridades -->
# 暗星 烬

## 💡 优先思路

如果没有**暗星纹章**，这套阵容依然可以玩，只是难度会明显更高，因为你几乎没有多余格子去补其他羁绊，整体变阵空间会小很多。

> 这套阵容最关键的点，是尽量拿到**暗星纹章**。

**2星卡莎**可以作为整局前中期的物理主C，一直帮你打到**2星烬**成型为止，这样能替你省下不少血量。

**卡尔玛**则可以吃剩下来的装备，因为你的主优先级还是要把物理输出装留给**烬**和**卡莎**。

## 🌱 前期阵容
![alt text](dark-star-prioridades__image.png)

## 🏆 8级阵容与纹章携带者
![alt text](dark-star-prioridades__image-1.png)

来源:Snoodyboo
