<!-- backup: huanling-rewards -->
# 幻灵战队奖励

## 100层

<p><strong>40%</strong></p>
<p><img src="https://static.datatft.com/images/reward/huanling0.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 0阶幻灵装备　<img src="https://static.datatft.com/images/reward/gold.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 2金币　<img src="https://static.datatft.com/images/heros/default/917233.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;border:2px solid rgb(175,175,175);"> 贝蕾亚</p>

<p><strong>40%</strong></p>
<p><img src="https://static.datatft.com/images/reward/huanling0.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 0阶幻灵装备　<img src="https://static.datatft.com/images/heros/default/917222.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;border:2px solid rgb(28,195,152);"> 金克丝</p>

<p><strong>20%</strong></p>
<p><img src="https://static.datatft.com/images/reward/huanling0.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 0阶幻灵装备　<img src="https://static.datatft.com/images/heros/default/917420.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;border:2px solid rgb(7,165,241);"> 俄洛伊</p>

## 200层

<p><strong>25%</strong></p>
<p><img src="https://static.datatft.com/images/equips/32421.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 无情砍削　<img src="https://static.datatft.com/images/reward/gold.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 2金币　⭐⭐ <img src="https://static.datatft.com/images/heros/default/917233.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;border:2px solid rgb(175,175,175);"> 贝蕾亚</p>

<p><strong>25%</strong></p>
<p><img src="https://static.datatft.com/images/equips/32402.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 火箭狂潮　<img src="https://static.datatft.com/images/heros/default/917222.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;border:2px solid rgb(28,195,152);"> 金克丝 x2</p>

<p><strong>25%</strong></p>
<p><img src="https://static.datatft.com/images/equips/32405.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 触手重击　<img src="https://static.datatft.com/images/reward/gold.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 2金币　<img src="https://static.datatft.com/images/heros/default/917420.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;border:2px solid rgb(7,165,241);"> 俄洛伊</p>

<p><strong>25%</strong></p>
<p><img src="https://static.datatft.com/images/equips/32424.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 附灵飞弹　<img src="https://static.datatft.com/images/reward/gold.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 2金币　<img src="https://static.datatft.com/images/heros/default/917893.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;border:2px solid rgb(7,165,241);"> 阿萝拉</p>

## 300层

<p><strong>25%</strong></p>
<p><img src="https://static.datatft.com/images/equips/32421.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 无情砍削　⭐⭐⭐ <img src="https://static.datatft.com/images/heros/default/917233.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;border:2px solid rgb(175,175,175);"> 贝蕾亚　<img src="https://static.datatft.com/images/reward/gold.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 7金币</p>

<p><strong>25%</strong></p>
<p><img src="https://static.datatft.com/images/equips/32402.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 火箭狂潮　⭐⭐ <img src="https://static.datatft.com/images/heros/default/917222.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;border:2px solid rgb(28,195,152);"> 金克丝　<img src="https://static.datatft.com/images/reward/gold.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 15金币</p>

<p><strong>25%</strong></p>
<p><img src="https://static.datatft.com/images/equips/32424.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 附灵飞弹　⭐⭐ <img src="https://static.datatft.com/images/heros/default/917893.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;border:2px solid rgb(7,165,241);"> 阿萝拉　<img src="https://static.datatft.com/images/reward/gold.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 7金币</p>

<p><strong>25%</strong></p>
<p><img src="https://static.datatft.com/images/equips/32405.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 触手重击　⭐⭐ <img src="https://static.datatft.com/images/heros/default/917420.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;border:2px solid rgb(7,165,241);"> 俄洛伊　<img src="https://static.datatft.com/images/reward/gold.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 7金币</p>

## 400层

<p><strong>25%</strong></p>
<p><img src="https://static.datatft.com/images/reward/huanling2.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 2阶幻灵装备　<img src="https://static.datatft.com/images/reward/gold.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 15金币　<img src="https://static.datatft.com/images/reward/cjyxfzq.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 次级英雄复制器 x3　<img src="https://static.datatft.com/images/reward/chaixie.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 装备拆卸器</p>

<p><strong>25%</strong></p>
<p><img src="https://static.datatft.com/images/reward/huanling2.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 2阶幻灵装备　<img src="https://static.datatft.com/images/equips/32424.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 附灵飞弹　⭐⭐ <img src="https://static.datatft.com/images/heros/default/917893.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;border:2px solid rgb(7,165,241);"> 阿萝拉　<img src="https://static.datatft.com/images/reward/chaixie.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 装备拆卸器</p>

<p><strong>20%</strong></p>
<p><img src="https://static.datatft.com/images/reward/huanling2.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 2阶幻灵装备　<img src="https://static.datatft.com/images/equips/32405.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 触手重击　⭐⭐ <img src="https://static.datatft.com/images/heros/default/917420.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;border:2px solid rgb(7,165,241);"> 俄洛伊　<img src="https://static.datatft.com/images/reward/chaixie.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 装备拆卸器</p>

<p><strong>20%</strong></p>
<p><img src="https://static.datatft.com/images/equips/32426.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 战兔十字弩　<img src="https://static.datatft.com/images/equips/539.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 鬼索的狂暴之刃　⭐⭐⭐ <img src="https://static.datatft.com/images/heros/default/917222.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;border:2px solid rgb(28,195,152);"> 金克丝　<img src="https://static.datatft.com/images/reward/gold.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 5金币　<img src="https://static.datatft.com/images/reward/chaixie.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 装备拆卸器</p>

<p><strong>10%</strong></p>
<p><img src="https://static.datatft.com/images/reward/huanling2.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 2阶幻灵装备　<img src="https://static.datatft.com/images/equips/32421.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 无情砍削　⭐⭐⭐ <img src="https://static.datatft.com/images/heros/default/917233.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;border:2px solid rgb(175,175,175);"> 贝蕾亚　<img src="https://static.datatft.com/images/reward/chaixie.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 装备拆卸器</p>

## 500层

<p><strong>34%</strong></p>
<p><img src="https://static.datatft.com/images/reward/huanling2.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 2阶幻灵装备 x2　<img src="https://static.datatft.com/images/reward/gold.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 30金币　<img src="https://static.datatft.com/images/reward/yxfzq.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 英雄复制器　<img src="https://static.datatft.com/images/reward/chaixie.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 装备拆卸器</p>

<p><strong>33%</strong></p>
<p><img src="https://static.datatft.com/images/reward/huanling2.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 2阶幻灵装备 x2　<img src="https://static.datatft.com/images/reward/gold.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 10金币　⭐⭐ <img src="https://static.datatft.com/images/heros/default/917114.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;border:2px solid rgb(255,183,1);"> 菲奥娜　⭐⭐ <img src="https://static.datatft.com/images/heros/default/917420.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;border:2px solid rgb(7,165,241);"> 俄洛伊</p>

<p><strong>33%</strong></p>
<p><img src="https://static.datatft.com/images/reward/huanling2.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 2阶幻灵装备 x2　<img src="https://static.datatft.com/images/reward/gold.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 10金币　<img src="https://static.datatft.com/images/reward/cjyxfzq.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 次级英雄复制器 x6</p>

## 600层

<p><strong>35%</strong></p>
<p><img src="https://static.datatft.com/images/reward/huanling3.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 3阶幻灵装备　⭐⭐ <img src="https://static.datatft.com/images/heros/default/917114.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;border:2px solid rgb(255,183,1);"> 菲奥娜　⭐⭐ <img src="https://static.datatft.com/images/heros/default/917420.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;border:2px solid rgb(7,165,241);"> 俄洛伊　⭐⭐ <img src="https://static.datatft.com/images/heros/default/917893.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;border:2px solid rgb(7,165,241);"> 阿萝拉</p>

<p><strong>35%</strong></p>
<p><img src="https://static.datatft.com/images/reward/huanling3.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 3阶幻灵装备　<img src="https://static.datatft.com/images/reward/huanling2.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 2阶幻灵装备　<img src="https://static.datatft.com/images/reward/gold.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 25金币　<img src="https://static.datatft.com/images/reward/chaixie.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 装备拆卸器 x2</p>

<p><strong>15%</strong></p>
<p><img src="https://static.datatft.com/images/equips/32418.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> OwO魔爆炮　<img src="https://static.datatft.com/images/equips/32402.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 火箭狂潮　⭐⭐⭐ <img src="https://static.datatft.com/images/heros/default/917222.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;border:2px solid rgb(28,195,152);"> 金克丝　<img src="https://static.datatft.com/images/reward/chaixie.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 装备拆卸器</p>

<p><strong>15%</strong></p>
<p><img src="https://static.datatft.com/images/reward/huanling3.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 3阶幻灵装备　<img src="https://static.datatft.com/images/equips/32413.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 进化余烬射击　⭐⭐⭐ <img src="https://static.datatft.com/images/heros/default/917893.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;border:2px solid rgb(7,165,241);"> 阿萝拉　⭐⭐ <img src="https://static.datatft.com/images/heros/default/917420.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;border:2px solid rgb(7,165,241);"> 俄洛伊　<img src="https://static.datatft.com/images/reward/chaixie.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 装备拆卸器</p>

## 700层

<p><strong>50%</strong></p>
<p><img src="https://static.datatft.com/images/reward/huanling3.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 3阶幻灵装备 x2　<img src="https://static.datatft.com/images/reward/gold.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 40金币</p>

<p><strong>50%</strong></p>
<p><img src="https://static.datatft.com/images/reward/huanling3.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 3阶幻灵装备 x2　<img src="https://static.datatft.com/images/reward/gold.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 12px;"> 20金币　⭐⭐ <img src="https://static.datatft.com/images/heros/default/917114.jpg" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;border:2px solid rgb(255,183,1);"> 菲奥娜</p>

## 800层

<p><strong>100%</strong></p>
<p><img src="https://static.datatft.com/images/equips/32417.png" style="display:inline-block;vertical-align:middle;width:52px;height:52px;margin:0 8px 0 0;"> 幻灵合体至尊炮</p>

来源：Datatft
