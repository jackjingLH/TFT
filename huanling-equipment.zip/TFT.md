<!-- backup: huanling-equipment -->
# 幻灵装备

## 0阶装备

<p><img src="https://static.datatft.com/images/equips/32419.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>破损原型</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/hp.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+100</span></p>
<p>效果：开局获得15%最大生命值护盾。</p>
<p><u>0阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32420.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>泄露原型</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ap.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+15%</span></p>
<p>效果：每5秒失去3法强，并获得1法力回复。</p>
<p><u>0阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32425.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>闪光原型</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ad.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+10%</span></p>
<p>效果：每4秒获得持续4秒的30%攻击速度。</p>
<p><u>0阶装备</u></p>

## 1阶装备

<p><img src="https://static.datatft.com/images/equips/32424.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>附灵飞弹</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ap.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+15%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/da.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+10%</span></p>
<p>效果：每3秒向射程内随机敌人发射飞弹，造成魔法伤害。</p>
<p><em>阿萝拉加成：命中敌人后，她会获得9法术加成。</em> <u>1阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32402.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>火箭狂潮</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ad.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+10%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/manaregen.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+3</span></p>
<p>效果：每消耗30法力发射4枚火箭，每枚造成30%攻击力物理伤害。</p>
<p><em>金克丝加成：技能子弹会改成额外伤害更高的火箭。</em> <u>1阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32421.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>无情砍削</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ad.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+10%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/sv.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+10%</span></p>
<p>效果：攻击会劈到目标和邻格敌人，造成30%攻击力伤害，且该伤害吸血效能更高。</p>
<p><em>贝蕾亚加成：施放技能时会连续触发6次。</em> <u>1阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32405.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>触手重击</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/hp.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+150</span></p>
<p>效果：每5秒召唤触手猛击目标，造成物理伤害并回复12%最大生命值。</p>
<p><em>俄洛伊加成：会额外生成一只触手追击被吸取的目标。</em> <u>1阶装备</u></p>

## 2阶装备

<p><img src="https://static.datatft.com/images/equips/32406.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>歼灭者</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ad.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+20%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ap.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+30%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/manaregen.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+3</span></p>
<p>效果：储存20%造成伤害，阵亡或18秒后引爆，对全体造成真实伤害。</p>
<p><u>2阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32426.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>战兔十字弩</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ad.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+20%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/as.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+25%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/crit.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+35%</span></p>
<p>效果：获得技能暴击；每4次暴击发射5支透体飞箭，每支造成物理伤害。</p>
<p><u>2阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32416.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>旋风切割器</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ad.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+20%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ap.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+20%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/armor.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+15</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/mr.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+15</span></p>
<p>效果：获得3个环身剃刀，造成魔法伤害并施加4秒双碎甲，对被碎甲目标额外增伤。</p>
<p><u>2阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32414.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>回响蝠刃</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ad.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+30%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/as.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+20%</span></p>
<p>效果：每3次攻击发射10个蝙蝠战刃，由最近3名敌人分摊伤害。</p>
<p><u>2阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32410.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>冰爆护甲</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/armor.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+30</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/hp.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+250</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/mr.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+30</span></p>
<p>效果：首次掉到70%和35%血时获得护盾，并释放冰霜新星晕眩附近敌人。</p>
<p><u>2阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32407.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>雌狮之怨</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/armor.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+30</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/hp.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+200</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/mr.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+30</span></p>
<p>效果：每失去15%最大生命值发射新月飞弹，造成基于双抗的物理伤害并窃取双抗。</p>
<p><u>2阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32403.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>耀光力场</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/hp.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+400</span></p>
<p>效果：获得额外生命值，并每秒对身边敌人造成基于最大生命值的魔法伤害。</p>
<p><u>2阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32404.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>炽烈短弓</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ad.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+10%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ap.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+40%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/manaregen.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+4</span></p>
<p>效果：每消耗20法力发射飞弹，造成魔法伤害并施加灼烧和重伤。</p>
<p><u>2阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32422.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>UwU魔爆炮</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ad.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+15%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/as.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+45%</span></p>
<p>效果：每次攻击向随机目标发射3道激光冲击波，造成物理伤害。</p>
<p><u>2阶装备</u></p>

## 3阶装备

<p><img src="https://static.datatft.com/images/equips/32408.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>幻灵启示录</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ad.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+30%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ap.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+30%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/manaregen.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+5</span></p>
<p>效果：储存20%伤害，每6秒和阵亡时对全体造成真实伤害。</p>
<p><u>3阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32415.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>战兔至尊弩炮</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ad.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+30%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/as.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+50%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/crit.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+50%</span></p>
<p>效果：获得技能暴击；每3次暴击发射6支飞箭，参与击杀时再追加一轮箭雨。</p>
<p><u>3阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32411.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>不息气旋</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ad.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+30%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ap.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+30%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/armor.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+40</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/mr.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+40</span></p>
<p>效果：获得6个环身剃刀，造成真实伤害并施加整场持续的双碎甲。</p>
<p><u>3阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32412.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>薇恩的炫彩战刃</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ad.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+30%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/as.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+50%</span></p>
<p>效果：每5次攻击发射30个炫彩战刃，由所有敌人分摊伤害。</p>
<p><u>3阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32423.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>深度冻结</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/armor.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+30</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/hp.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+550</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/mr.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+30</span></p>
<p>效果：血量降到多个阈值时获得护盾并释放冰霜新星，后续新星范围还会变大。</p>
<p><u>3阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32409.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>猛狮之殇</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/armor.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+40</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/hp.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+400</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/mr.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+40</span></p>
<p>效果：每失去15%最大生命值向3条直线发射飞弹，造成基于双抗的物理伤害并窃取双抗。</p>
<p><u>3阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32401.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>日蚀之刻</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/hp.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+800</span></p>
<p>效果：获得额外生命值；每秒对2格内敌人造成基于最大生命值的伤害，并按造成伤害回血。</p>
<p><u>3阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32413.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>进化余烬射击</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ad.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+40%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ap.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+40%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/manaregen.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+5</span></p>
<p>效果：每消耗15法力发射飞弹，造成魔法伤害并施加灼烧、重伤，还会留下持续伤害区域。</p>
<p><u>3阶装备</u></p>

---

<p><img src="https://static.datatft.com/images/equips/32418.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>OwO魔爆炮</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ad.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+35%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/as.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+75%</span></p>
<p>效果：每次攻击向随机目标发射9道激光冲击波，造成物理伤害。</p>
<p><u>3阶装备</u></p>

## 4阶装备

<p><img src="https://static.datatft.com/images/equips/32417.png" style="display:inline-block;vertical-align:middle;width:84px;height:84px;margin:0 12px 0 0;"> <strong>幻灵合体至尊炮</strong></p>
<p>属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ad.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+100%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/ap.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+100%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/as.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+100%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/armor.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+100</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/crit.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+75%</span></p>
<p>附加属性：<span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/hp.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+10000</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/mr.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+100</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/manaregen.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+10</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/sv.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+100%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/da.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+100%</span> / <span style="white-space:nowrap;"><img src="https://static.datatft.com/images/heros/other/dr.png" style="display:inline-block;vertical-align:-3px;width:18px;height:18px;margin:0 4px 0 0;">+50%</span></p>
<p>效果：幻灵科技的顶点。</p>
<p><u>4阶装备</u></p>

来源：Datatft
